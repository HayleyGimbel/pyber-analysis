# Scatter Py

### Instructions

* Using the file provided as a starter, create a scatter plot that matches the image provided.

### BONUS

* Create a new list called "scoop_price", fill it with values, and then set it so that the size of the dots are set according to those values.

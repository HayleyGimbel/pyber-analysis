# Bike Trippin

## Instructions

* Create a bar chart using Pandas and MatplotLib that visualizes how many individual bike trips were taken by each gender.

* Create a pie graph using Pandas and MatplotLib that can be used to visualize the trip duration of a single bike split up by gender.

## Hint

* There is a buggy value stored within the "gender" column of the original DataFrame. In order to create an accurate chart, this value will need to be found and removed.
